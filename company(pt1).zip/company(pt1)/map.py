mydata = [
['lat','lng','university'],
[42.47895,-71.18925, 'Northeastern University'],
[40.6975,-89.61062, 'University of Hong Kong, Illinois Institute of Technology, Bradley University'],
[32.77652,35.02261, 'Technion'],
[18.46031,73.83568, 'Viswakarma Institute, Pune, India'],
[39.32459,-82.09905, 'University of Piraeus, Athens'],
[47.65417,-122.30261, 'University of Washington'],
[40.06939,-0.11255, 'UMD'],
[41.34958,-74.14007, 'Tufts University'],
[42.47895,-71.18925, 'Northeastern University'],
[49.5725,3.170833, 'Monash University'],
[40.6975,-89.61062, 'University of Hong Kong, Illinois Institute of Technology, Bradley University'],
[41.17836,-76.26033, 'Kharkiv State Academy of Municipal Economy, Ukraine'],
[32.77652,35.02261, 'Technion'],
[23.20786,77.39933, 'Kokshetau Institute of Economics and Management'],
[18.46031,73.83568, 'Viswakarma Institute, Pune, India'],
[32.11047,34.78595, 'RSU named S.A. Esenin'],
[39.32459,-82.09905, 'University of Piraeus, Athens'],
[39.390897,-99.066067, 'Tavrida National V.I. Vernadsky University'],
[47.65417,-122.30261, 'University of Washington'],
[32.0958,-110.82376, 'Warsaw University of Technology'],
[40.06939,-0.11255, 'UMD'],
[12.01862,79.85356, 'Pondicherry University'],
[41.34958,-74.14007, 'Tufts University'],
[49.5725,3.170833, 'Monash University'],

];

# open file
with open('where.csv', 'w+') as f:

	# write elements of list
	for items in mydata:
		f.write('%s\n' %items)

# close the file
f.close()
