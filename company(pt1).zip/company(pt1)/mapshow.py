import pandas as pd
import folium
from folium.plugins import MarkerCluster
import random

N=folium.Map(Location=[15.737855822654543, 79.26665185789177],tiles="OpenStreetMap")
df=pd.read_csv('where.csv')
markerCluster=MarkerCluster().add_to(N)
for i,row in df.iterrows():
    lat=df.at[i,'lat']
    lng=df.at[i,'lng']
    col=df.at[i,'university']
    popup=df.at[i,'university']
    folium.Marker(location=[lat,lng],popup=popup,icon=folium.Icon(color='blue')).add_to(markerCluster)
N.save('mapshow.html')
